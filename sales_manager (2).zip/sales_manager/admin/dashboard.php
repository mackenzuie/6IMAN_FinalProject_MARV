<?php
session_start();
require '../db_connect.php'; 
require 'includes/session_check.php'; 
include 'includes/header.php'; 

if (!isset($_SESSION['staff_id'])) {
    header("Location: login.php");
    exit();
}

$adminName = $_SESSION['staff_name'];

$metrics = [
    'total_sales' => 0,
    'total_products' => 0,
    'total_staff' => 0,
    'low_stock_products' => 0
];

try {
    // get tot sales 
    $salesColumns = ['total_amount', 'amount', 'sales_total', 'sale_total'];
    foreach ($salesColumns as $column) {
        $salesQuery = $conn->query("SELECT SUM($column) AS total_sales FROM sales");
        if ($salesQuery && $salesQuery->num_rows > 0) {
            $metrics['total_sales'] = $salesQuery->fetch_assoc()['total_sales'];
            break;
        }
    }

    // Tot prods
    $productColumns = ['id', 'product_id', 'count'];
    foreach ($productColumns as $column) {
        $productsQuery = $conn->query("SELECT COUNT(DISTINCT $column) AS total_products FROM products");
        if ($productsQuery && $productsQuery->num_rows > 0) {
            $metrics['total_products'] = $productsQuery->fetch_assoc()['total_products'];
            break;
        }
    }

    // Tot staff
    $staffColumns = ['id', 'staff_id', 'employee_id'];
    foreach ($staffColumns as $column) {
        $staffQuery = $conn->query("SELECT COUNT(DISTINCT $column) AS total_staff FROM staff");
        if ($staffQuery && $staffQuery->num_rows > 0) {
            $metrics['total_staff'] = $staffQuery->fetch_assoc()['total_staff'];
            break;
        }
    }

    // low stock prod 
    $stockColumns = ['stock_quantity', 'quantity', 'inventory', 'stock'];
    foreach ($stockColumns as $column) {
        $lowStockQuery = $conn->query("SELECT COUNT(*) AS low_stock FROM products WHERE $column < 10 AND $column > 0");
        if ($lowStockQuery && $lowStockQuery->num_rows > 0) {
            $metrics['low_stock_products'] = $lowStockQuery->fetch_assoc()['low_stock'];
            break;
        }
    }

} catch (Exception $e) {
    error_log("Dashboard Metrics Error: " . $e->getMessage());
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Business Dashboard</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.7.2/font/bootstrap-icons.css" rel="stylesheet">
    <style>
        * {
            box-sizing: border-box;
            font-family: 'Arial', sans-serif;
            margin: 0;
            padding: 0;
        }
        body {
            background-color: #f9f9f9;
            line-height: 1.6;
        }
        .header {
            background-color: #ffcc00;
            box-shadow: 0 2px 4px rgba(0,0,0,0.1);
            padding: 15px 20px;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        .welcome-message {
            font-size: 18px;
            color: #333;
            font-weight: 600;
        }
        .motivational-phrase {
            font-size: 16px;
            font-weight: 600;
            color: #1e1e2f;
            text-align: right;
            padding-right: 10px;
            letter-spacing: 0.5px;
        }
        .dashboard-container {
            max-width: 1200px;
            margin: 30px auto;
            padding: 0 20px;
        }
        .dashboard-title {
            text-align: center;
            margin-bottom: 30px;
            color: #333;
            font-size: 28px;
            font-weight: bold;
            background-color: #ffcc00;
            padding: 10px 0;
            border-radius: 8px;
        }
        .metrics-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
            gap: 20px;
        }
        .metric-card {
            background-color: #ffffff;
            border-radius: 8px;
            padding: 20px;
            box-shadow: 0 4px 6px rgba(0,0,0,0.1);
            text-align: center;
            transition: transform 0.3s ease, box-shadow 0.3s ease;
            border-top: 5px solid #ffcc00;
        }
        .metric-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 6px 12px rgba(0,0,0,0.15);
        }
        .metric-icon {
            font-size: 2.5rem;
            margin-bottom: 15px;
            color: #ff6600;
            opacity: 0.8;
        }
        .metric-value {
            font-size: 2rem;
            font-weight: bold;
            color: #333;
            margin-bottom: 10px;
        }
        .metric-label {
            text-transform: uppercase;
            font-size: 0.9rem;
            color: #666;
            letter-spacing: 1px;
        }
    </style>
</head>
<body>
    <div class="header">
        <div class="welcome-message">
            Welcome, <?php echo htmlspecialchars($adminName); ?>!
        </div>
        <div class="motivational-phrase">
            🌟 Great things happen to those who work hard!
        </div>
    </div>

    <div class="dashboard-container">
        <h1 class="dashboard-title">Business Overview</h1>
        
        <div class="metrics-grid">
            <div class="metric-card">
                <i class="bi bi-cash-stack metric-icon"></i>
                <div class="metric-value">₱<?php echo number_format($metrics['total_sales'], 2); ?></div>
                <div class="metric-label">Total Sales</div>
            </div>
            
            <div class="metric-card">
                <i class="bi bi-box-seam metric-icon"></i>
                <div class="metric-value"><?php echo $metrics['total_products']; ?></div>
                <div class="metric-label">Total Products</div>
            </div>
            
            <div class="metric-card">
                <i class="bi bi-people metric-icon"></i>
                <div class="metric-value"><?php echo $metrics['total_staff']; ?></div>
                <div class="metric-label">Total Staff</div>
            </div>
            
            <div class="metric-card">
                <i class="bi bi-exclamation-triangle metric-icon"></i>
                <div class="metric-value"><?php echo $metrics['low_stock_products']; ?></div>
                <div class="metric-label">Low Stock Products</div>
            </div>
        </div>
    </div>
</body>
</html>
