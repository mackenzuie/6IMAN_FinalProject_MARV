<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Panel | Marv Shawarma</title>
    <style>
        * {
            box-sizing: border-box;
            margin: 0;
            padding: 0;
            font-family: 'Poppins', sans-serif;
        }
        body {
            display: flex;
            height: 100vh;
            background: #f8f1e7; 
            color: #333;
        }
        
        .sidebar {
            width: 260px;
            height: 100vh;
            background: rgba(0, 0, 0, 0.9); 
            backdrop-filter: blur(10px);
            color: white;
            padding: 20px;
            position: fixed;
            left: 0;
            top: 0;
            box-shadow: 4px 0 10px rgba(0, 0, 0, 0.1);
            transition: 0.3s ease-in-out;
        }
        .sidebar h2 {
            text-align: center;
            font-size: 24px;
            text-transform: uppercase;
            letter-spacing: 1px;
            margin-bottom: 20px;
            border-bottom: 2px solid #ffcc00; 
            padding-bottom: 10px;
        }
        .sidebar ul {
            list-style: none;
            padding: 0;
        }
        .sidebar ul li {
            margin: 10px 0;
        }
        .sidebar ul li a {
            display: flex;
            align-items: center;
            padding: 12px 20px;
            font-size: 18px;
            text-decoration: none;
            color: white;
            border-radius: 8px;
            transition: all 0.3s ease-in-out;
        }
        .sidebar ul li a i {
            margin-right: 10px;
            font-size: 20px;
        }

        .logout {
            margin-top: 40px;
            text-align: center;
        }
        .logout a {
            display: inline-block;
            background: #ff4500; 
            color: white;
            padding: 12px 25px;
            border-radius: 8px;
            font-size: 18px;
            font-weight: bold;
            text-decoration: none;
            transition: all 0.3s ease-in-out;
        }
        .logout a:hover {
            background: #d14000;
        }
        
        .main-content {
            margin-left: 260px;
            padding: 30px;
            flex: 1;
        }
    </style>
    <script src="https://kit.fontawesome.com/a076d05399.js" crossorigin="anonymous"></script>
</head>
<body>

    <div class="sidebar">
        <h2>Marv Shawarma</h2>
        <ul>
            <li><a href="dashboard.php" class="active"><i class="fas fa-home"></i> Dashboard</a></li>
            <li><a href="sales.php"><i class="fas fa-chart-line"></i> Sales</a></li>
            <li><a href="inventory.php"><i class="fas fa-box"></i> Inventory</a></li>
            <li><a href="staff_management.php"><i class="fas fa-users"></i> Manage Staff</a></li>
        </ul>
        <div class="logout">
            <a href="logout.php"><i class="fas fa-sign-out-alt"></i> Logout</a>
        </div>
    </div>

    <div class="main-content">
